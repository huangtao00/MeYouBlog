-r requirements.txt

Faker
factory_boy
mongomock
coverage
